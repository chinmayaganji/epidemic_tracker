<?php
$na=$_POST['l'];
$em=$_POST['la'];
$pa=$_POST['d'];
$dc=$_POST['dc'];

$servername = "sql200.epizy.com";
$username = "epiz_24318821";
$password = "MlRpv9MjnyA";
$dbname = "epiz_24318821_hospital";
if($na&&$em){
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM location";

$result = $conn->query($sql);
//echo($result);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["lat"].<br>";
    }
    }

$conn->close();
?>